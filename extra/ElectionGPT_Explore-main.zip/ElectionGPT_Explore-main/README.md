# Election ChatBOT

## Python Setup
To make sure we all use the same version of Python, set up a virtual environment:

